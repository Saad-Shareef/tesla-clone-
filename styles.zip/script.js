// Countdown Timer (optional)
const countdownElement = document.getElementById('countdown');
let countdownTime = new Date().getTime() + (14 * 60 * 60 * 1000); // 14 hours from now

function updateCountdown() {
    const now = new Date().getTime();
    const timeLeft = countdownTime - now;

    const hours = Math.floor((timeLeft / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((timeLeft / (1000 * 60)) % 60);
    const seconds = Math.floor((timeLeft / 1000) % 60);

    countdownElement.innerHTML = `${hours}:${minutes}:${seconds}`;
}

setInterval(updateCountdown, 1000);
